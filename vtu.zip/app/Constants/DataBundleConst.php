<?php

namespace App\Constants;

class DataBundleConst {
    const TOPUP_RECHARGE    = "RECHARGE";
    const TOPUP_BUNDLE      = "BUNDLE";
    const TOPUP_DATA        = "DATA";
    const SLUG        = "DATA_BUNDLE";

}

?>
